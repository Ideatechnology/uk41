<!-- sosial media -->
<div class="panel panel-warning" >
  <div class="panel-heading" ><?php echo lang("page_menu_other");?></div>
  <div class="panel-body">
<?php
echo collapsenav2($this->uri->segment(5));
?>
</div>
</div>

