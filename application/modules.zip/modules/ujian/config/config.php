<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

$config['module_config'] = array(
	'description'	=> " Beta 1.0",
	'name'		=>'Examation',
	'version'		=> 'Beta 1.0',
	'author'		=> 'Harry Ridwan Ramadan'
);

