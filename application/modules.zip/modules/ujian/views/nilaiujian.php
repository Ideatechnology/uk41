 <div class="row"> 
     
 <div class="col-sm-6">         

     <div class="panel panel-default">
       <div class="panel-heading">
      
        <h4>Hasil Ujian</h4></div>
        <div class="panel-body">
  
        <ul class="nav nav-pills nav-stacked" style="max-width: 260px;">
      <li>
        <a href="#">
          <span class="badge pull-right"><?php echo $hasil_ujian->total_benar;?></span>
          Jawaban Benar
        </a>
      </li>
      <li>
        <a href="#">
          <span class="badge pull-right"><?php echo $hasil_ujian->total_salah;?></span>
          Jawaban Salah
        </a>
      </li>
        <li>
        <a href="#">
          <span class="badge pull-right"><?php echo $hasil_ujian->total_tidak_dijawab;?></span>
          Total Tidak Di Jawab
        </a>
      </li>
      <li>
        <a href="#">
          <span class="badge pull-right"><?php echo $ujian->nilai_kelulusan;?></span>
          Prosentase Kelulusan
        </a>
      </li>
    </ul>

            <br />
        <div class='section' style="margin-left:10px;">    
		<span class="pull-left"> Bagikan Keteman Anda : &nbsp;</span> 
                  <div class='addthis_toolbox addthis_default_style'>
                  	
                  <a class='addthis_button_preferred_1'></a>
                  <a class='addthis_button_preferred_2'></a>
                  <a class='addthis_button_preferred_3'></a>
                  <a class='addthis_button_preferred_4'></a>
                  <a class='addthis_button_compact'></a>
                  <a class='addthis_counter addthis_bubble_style'></a>
                  </div>
                  <script type='text/javascript' src='<?php echo Template::theme_url("js/addthis_widget.js");?>'></script>
                  </div> 

        </div>
     </div>
     
     
 </div>
 <div class="col-sm-6">     
 
     <style>
         
         .winner{
             font-size:80px;
             color:#eb9316;
         }
         
         .lose{
             font-size:80px;
             color:#A00;
         }
         
     </style>
     
     <div class="panel panel-default">
       
        <div class="panel-body">
            <div class="text-center">
                <h1><?php echo $status; ?></h1> 
            <?php echo $icon; ?>
            <h4>Dengan Score : <?php echo $hasil_ujian->score;?></h4>
            <a href="<?php echo site_url("/ujian/startujian/".$ujian->kode_ujian);?>" class="btn btn-primary">Coba Lagi</a>
            </div>
            
        </div>
     </div>
 
 </div>
 </div>    

<div class="row">
    
    <div class="col-sm-12">
        
          <div class="panel panel-default">
        <div class="panel-heading">
      
        <h4>Detail Jawaban Anda 
        
            <span class="pull-right">
                Jumlah soal : <?php echo $ujian->jumlah_soal;?>
                |
                Durasi Waktu : <?php echo $ujian->durasi_waktu;?> Menit
            </span>
        </h4></div>
              
              
        <div class="panel-body">
            
            <?php 
            $hasil= json_decode($hasil_ujian->hasil_jawaban);
             ?>
            
            
            <div class="row">
     
        <?php 
        $no=0;
        foreach($soal as $row_soal): 
        
            if($hasil[$no]->status=="Benar"){
                $color="color:#009900";
            }else{
                $color = "color:#A00";
            }
            
           
            
            
        ?>        
        <div class="col-sm-6 col-md-4">
       <h3 style="<?php echo $color;?>">Soal Ke <?php echo $row_soal->urutan;?> - <?php echo $hasil[$no]->status;?></h3>
        <div class="thumbnail" >
          <div class="caption">
              <p></p>
              <p>
                  
                  <?php echo $row_soal->question_name;?>
              </p>
              <ul>
                  <li style="<?php echo $hasil[$no]->answer==1?"color:#A00;":"";?><?php echo $row_soal->answer==1?"color:#009900;":"";?>">A. <?php echo $row_soal->answer1;?></li>
                  <li style="<?php echo $hasil[$no]->answer==2?"color:#A00;":"";?><?php echo $row_soal->answer==2?"color:#009900;":"";?>">B. <?php echo $row_soal->answer2;?></li>
                  <li style="<?php echo $hasil[$no]->answer==3?"color:#A00;":"";?><?php echo $row_soal->answer==3?"color:#009900;":"";?>">C. <?php echo $row_soal->answer3;?></li>
                  <li style="<?php echo $hasil[$no]->answer==4?"color:#A00;":"";?><?php echo $row_soal->answer==4?"color:#009900;":"";?>">D. <?php echo $row_soal->answer4;?></li>
                  <li style="<?php echo $hasil[$no]->answer==5?"color:#A00;":"";?><?php echo $row_soal->answer==5?"color:#009900;":"";?>">E. <?php echo $row_soal->answer5;?></li>
              </ul>
           
             </div>
        </div>
      </div>
                <?php 
                $no++;
                endforeach; ?>
                
              
               
                
                
            </div>
            
            
            
        </div>
          </div>
        
    </div>
    
</div>