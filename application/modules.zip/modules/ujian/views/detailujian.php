<?php

Assets::add_js("
$(document).ready(function(){
  $('#registrasi').click(function () {
    var btn = $(this)
    btn.button('loading')
    $.ajax(
        {url: '".site_url("/ujian/registrasi/".$this->uri->segment(3))."', success: function(result){
        $('#result').html(result);
        $('#registrasi').hide();
    }}
    ).always(function () {
      btn.button('reset')
    });
  });
  });
  ","inline");
?>




<div class="col-md-12">
<div class="panel panel-default">
       <div class="panel-body">

<h1><?php echo strtoupper($query->judul_ujian);?></h1>
<p><?php echo $query->keterangan;?></p>

<table class="table table-bordered">
  <tbody>
      <tr>
    <th><?php echo $this->ujian_model->getField()->nilai_kelulusan;?></th>
    <td><?php echo $query->nilai_kelulusan;?> %</td>
      </tr>
      <tr>
    <th><?php echo $this->ujian_model->getField()->durasi_waktu;?></th>
    <td><?php echo $query->durasi_waktu;?> Menit</td>
  </tr>
  
  <tr>
    <th><?php echo $this->ujian_model->getField()->jumlah_soal;?></th>
    <td><?php echo $query->jumlah_soal;?></td>
  </tr>
  <tr>
            <th><?php echo $this->ujian_model->getField()->pembayaran;?></th>
            <td><?php echo formatUang($query->pembayaran);?></td>
        </tr>
  
</tbody></table>

<div id="result"></div>

<?php if($this->registrasi_model->checkRegistrasi($this->auth->user_id(),$this->uri->segment(3))==FALSE): ?>
<button class="btn btn-warning" data-loading-text="Loading..." id="registrasi">Registrasi</button>
<?php else: ?>
<div class="alert alert-info">Silakan untuk melakukan pembayaran agar 
tombol start ujian aktif setelah melakukan pembayaran lakukan konfirmasi pembayaran 
<a href="<?php echo site_url("/konfirmasi-pembayaran");?>">disini</a>
agar kami bisa memproses pembayaran anda.</div>
<?Php endif; ?>


<a href="<?php echo site_url("/ujian/startujian/".$this->uri->segment(3));?>" 
   <?php if($this->registrasi_model->checkPembayaran($this->auth->user_id(),$this->uri->segment(3))==FALSE): ?>
   disabled="disabled" 
   <?php endif; ?>
   class="btn btn-primary">Start Ujian</a>



 </div>
</div>
</div>


