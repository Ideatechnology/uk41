
<!-- main col right -->
<div class="col-sm-7">
     
    <?php if(isset($query)){ ?>
    <?php foreach($query as $row): ?>
     <div class="panel panel-default">
       <div class="panel-heading">
      
        <h4>
        <a href="<?php echo site_url("ujian/detailujian/".$row["kode_ujian"]);?>" class="pull-right"><small>Lihat Detail</small></a>
        <?php echo $row["judul_ujian"];?></h4></div>
        <div class="panel-body">
          <p><small><span class="glyphicon glyphicon-calendar"></span> Tanggal Buat : <?php echo tgl_indo(date("Y-m-d",strtotime($row["created_on"])));?> - Jam <?php echo date("H:i",strtotime($row["created_on"]));?> Wib</small></p>
          
          <p><?php echo $row["keterangan"];?>
        </p>
        
         
        <hr />
        Jumlah peserta terdaftar 100 Orang
        </div>
     </div>
    <?php endforeach; ?>
    <?php } ?>
     
         
  <?php
	echo $this->pagination->create_links();
	?>
  
  
</div>

                          
<!-- main col left --> 
<div class="col-sm-5">
 
    <div class="panel panel-default">
       <div class="panel-body">
        <p class="lead"><?php echo ucfirst($current_user->display_name);?></p>
        <p>14 Daftar Ujian , 13 Mengikuti Ujian , 1 Lulus Ujian, 2 Belum Lulus</p>
        
       
      </div>
    </div>

 
  
 
   
 
</div>
