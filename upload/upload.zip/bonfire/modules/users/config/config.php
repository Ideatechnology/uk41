<?php if (!defined('BASEPATH')) exit('No direct script access allowed');

$config['module_config'] = array(
	'description'	=> 'Allows users to exist in Bonfire.',
	'author'		=> 'Bonfire Team',
	'name'			=> 'Pengguna',
	'weights'		=> array(
		'settings'	=> 1
	)
);