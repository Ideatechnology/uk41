<!-- main col right -->
<div class="col-sm-7">

   <div class="panel panel-default">
       <div class="panel-heading">
      
        <h4>
        <a href="index.php?page=detailujian" class="pull-right"><small>Lihat Detail</small></a>
        TRY OUT AIPKI (UK-CBT)</h4></div>
        <div class="panel-body">
          <p><small><span class="glyphicon glyphicon-calendar"></span> Jadwal Ujian : 12 Desember 2015 - 14 April 2015</small></p>
          
          <p>AIPKI dengan IDI untuk membahas masa depan ujian kompetensi dokter 
          di Indonesia di Aula FKUI. Pertemuan dihadiri Ketua AIPKI, 
          Ketua IDI, Perwakilan DIKTI, Perwakilan Dekanat, dan perwakilan BEM.
        </p>
        
         <p><small >Tahapan : Batch 1<small class="text-muted">|</small> Batch 2 <small class="text-muted">|</small>
          Batch 3 <small class="text-muted">|</small></small></p>
         
        <hr />
        Jumlah peserta terdaftar 100 Orang
        </div>
     </div>
     
     
     </div>