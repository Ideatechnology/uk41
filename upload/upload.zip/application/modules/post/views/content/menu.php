<ul>
	<li><a href="<?php echo site_url(SITE_AREA .'/content/post') ?>">Manage Post</a></li>
	<li><a href="<?php echo site_url(SITE_AREA .'/content/post/kategori') ?>">Kategori Post</a></li>
</ul>
