<?php echo theme_view('_mobile_header'); ?>

    <?php echo theme_view('kontent'); ?>
  
<?php echo theme_view('_mobile_footer'); ?>
